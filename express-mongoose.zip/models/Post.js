const mongoose = require('mongoose');
const AutoIncrementFactory = require('mongoose-sequence');

const postSchema = new mongoose.Schema({
    title: { type: String, required: true },
    content: { type: String, default: '내용 없음' }
  });

  const AutoIncrement = AutoIncrementFactory(mongoose);
  const option = { inc_field : 'post_id' };
  postSchema.plugin(AutoIncrement, option);

  module.exports = mongoose.model('Post', postSchema);