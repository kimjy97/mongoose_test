const cors = require('cors');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const Post = require('./models/Post');


var express = require('express')

var app = express()
app.use(bodyParser.urlencoded({ extended: false }));
app.use(cors());
app.use(bodyParser.json());

const connection = mongoose
  .connect('mongodb://127.0.0.1:27017')
  .then(() => console.log('Successfully connected to mongodb'))
  .catch(e => console.error(e));

app.listen(5000, function() {
    console.log("start! express server on port 5000")
})

app.post('/posting', function(req, res) {
    const data = req.body;
    const post = new Post(data);
    post.save().then(() => {
        console.log('Saved successfully');
        res.status(200).send('success');
    });
})